<!--O que vai armazenar -->
<script setup>
defineProps(["title","news","rate"])
const emit = defineEmits(['aumentarFonte', 'diminuirFonte'])

function aumentarFonte(){

    emit('aumentarFonte')
}

function diminuirFonte(){
    
    emit('diminuirFonte')
}

</script>

<!--como se comporta em tela-->

<template>
    <div class="noticia">
        <h4>{{title}}</h4>
    
    
        <p>{{news}}</p>
    
    
        <p>{{rate}} </p>
        <button @click="aumentarFonte()">+</button>
        <button @click="diminuirFonte()">-</button>
    </div>
    
</template>

<style scoped>

.noticia{
    border: 1px solid silver;
    background-color: rgb(218, 149, 23);
    margin: 10px;
}

</style>