<script setup>

defineProps(['title'])

</script>
<!------------------------>
<template>
    <!--implementa a variável -->
    <h1>{{ title }}</h1>

</template>



<style>

</style>