<script setup>
import TituloPrincipal from './components/TituloPrincipal.vue'
import NoticiasEsportivas from './components/NoticiasEsportivas.vue';

import{ref} from 'vue'

const titulo = ref('Minha var para o título')

const tamanhoFonte = ref(1)

const noticias = ref(
    [
      {title: 'Tenis', news: 'Campeonato de tenis no Senac', rate: 1},
      {title: 'Volei', news: 'Campeonato de volei no Senac', rate: 5},
      {title: 'Basquete', news: 'Campeonato de basquete no Senac', rate: 6} 
    ]
    )
</script>

<template>
  <div>
    <titulo-principal title = "titulo"/>
    <!--ao colocar dois pontos, ele importa o referenciado no const, caso 
    <!contrário, irá entender-se como uma informação ao invés de um parametro-->
    <titulo-principal :title = "titulo"/>
    
    <!--ação para botão, a váriavel titulo recebe o título e sua 
    <-- função aumenta as letras -->

    <button @click="titulo = titulo.toUpperCase()">Upper</button>
    <div :style="{fontSize: tamanhoFonte + 'em'}">
      <noticias-esportivas v-for="n in noticias" :key="n.title"

        :title="n.title"
        :news="n.news"
        :rate="n.rate"

        @aumentarFonte="tamanhoFonte++"
        @diminuirFonte="tamanhoFonte--"
      >

      </noticias-esportivas>
    </div>

  </div>
  
</template>

<style scoped>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}
</style>
